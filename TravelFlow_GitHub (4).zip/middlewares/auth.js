const {Usuario}=require('../models');
async function loadUser(req,res,next){
 try {const user=req.session.uid?await Usuario.findByPk(req.session.uid,{attributes:['id','nome','email','tipo','ativo']}):null;
 if(user&&user.ativo){req.user=user;res.locals.user=user.get({plain:true});res.locals.admin=user.tipo==='admin';} else delete req.session.uid;
 next();}catch(e){next(e);}
}
function auth(req,res,next){if(!req.user)return res.redirect('/login');next();}
function admin(req,res,next){if(req.user?.tipo!=='admin')return res.status(403).render('error',{title:'Acesso negado',message:'Esta área é exclusiva do administrador.'});next();}
module.exports={loadUser,auth,admin};
