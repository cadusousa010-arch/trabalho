const crypto=require('node:crypto');
function csrf(req,res,next){
 if(!req.session.csrf)req.session.csrf=crypto.randomBytes(32).toString('hex');
 res.locals.csrf=req.session.csrf;
 if(req.method==='POST'){
  const token=req.body?._csrf;
  if(typeof token!=='string'||!/^[0-9a-f]{64}$/.test(token)||token.length!==64||!crypto.timingSafeEqual(Buffer.from(token,'utf8'),Buffer.from(req.session.csrf,'utf8')))
   return res.status(403).render('error',{title:'Solicitação inválida',message:'Atualize a página e tente novamente.'});
 }
 next();
}
module.exports={csrf};
// Limitação simples para o servidor escolar local; não é um armazenamento distribuído.
const attempts=new Map();
function loginLimit(req,res,next){const now=Date.now();for(const [key,v] of attempts)if(v.until<=now)attempts.delete(key);const key=req.ip;const v=attempts.get(key)||{count:0,until:now+15*60*1000};if(v.count>=20)return res.status(429).render('error',{title:'Muitas tentativas',message:'Tente novamente em alguns minutos.'});v.count++;attempts.set(key,v);next();}
module.exports.loginLimit=loginLimit;
