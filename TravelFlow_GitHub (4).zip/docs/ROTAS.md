# Tabela de rotas

GET = consulta ou formulário. POST = alteração; todo POST exige token CSRF. `:id` identifica a viagem/usuário/destino conforme o recurso; `:item` identifica um registro filho.

| Método | URL | Acesso / ação |
|---|---|---|
| GET | / e /destinos | Público; catálogo e pesquisa |
| GET / POST | /login | Público; formulário / autenticação |
| GET / POST | /cadastro | Público; formulário / criar conta comum |
| POST | /sair | Autenticado; encerra sessão |
| GET / POST | /perfil | Autenticado; consultar / editar perfil próprio |
| GET | /usuario | Usuário; painel |
| GET | /meu-roteiro | Autenticado; roteiro das próprias viagens |
| GET | /viagens | Usuário; Kanban |
| GET | /viagens/novo | Usuário; formulário |
| POST | /viagens | Usuário; criar |
| GET | /admin | Admin; indicadores |
| GET | /admin/usuarios | Admin; pesquisar/listar |
| GET | /admin/usuarios/novo | Admin; formulário |
| POST | /admin/usuarios | Admin; criar usuário comum |
| GET / POST | /admin/usuarios/:id/editar | Admin; editar e ativar/desativar |
| POST | /admin/usuarios/:id/excluir | Admin; excluir usuário comum |
| GET | /admin/destinos | Admin; pesquisar/listar |
| GET | /admin/destinos/novo | Admin; formulário |
| POST | /admin/destinos | Admin; criar destino |
| GET / POST | /admin/destinos/:id/editar | Admin; editar, ativar/desativar |
| POST | /admin/destinos/:id/excluir | Admin; excluir destino não vinculado |
| GET | /admin/viagens | Admin; listar e filtrar viagens |

Nas rotas a seguir, `BASE` é `/viagens` (usuário proprietário) ou `/admin/viagens` (admin). `:tipo` só aceita `tarefas`, `roteiros`, `despesas`, `etiquetas`.

| Método | URL | Ação |
|---|---|---|
| GET | BASE/:id | Abrir viagem e itens |
| GET / POST | BASE/:id/editar | Editar viagem |
| POST | BASE/:id/excluir | Excluir viagem e filhos |
| POST | BASE/:id/status | Alterar coluna Kanban |
| GET | BASE/:id/:tipo/novo | Formulário de item |
| POST | BASE/:id/:tipo | Criar item |
| GET / POST | BASE/:id/:tipo/:item/editar | Editar item |
| POST | BASE/:id/:tipo/:item/excluir | Excluir item |
| GET | BASE/:id/tarefas/:item | Detalhe da tarefa |
| POST | BASE/:id/tarefas/:item/concluir | Concluir ou reabrir |
| POST | BASE/:id/tarefas/:item/etiquetas | Associar etiquetas |
| POST | BASE/:id/tarefas/:item/comentarios | Adicionar comentário |

| GET | /destinos/:id | Detalhe público |
| GET | /favoritos | Favoritos do usuário |
| POST | /destinos/:id/favorito | Adicionar ou remover favorito |
| GET | /minhas-tarefas e /minhas-despesas | Registros próprios |
| GET | /admin/tarefas | Tarefas administrativas |
| GET | /admin/usuarios/:id/viagens | Viagens de usuário |
| GET | /admin/relatorios | Relatórios por data; CSV por parâmetro csv |
| POST | BASE/:id/listas | Criar lista |
| POST | BASE/:id/listas/:lista/editar | Renomear lista |
| POST | BASE/:id/listas/:lista/excluir | Transferir tarefas e excluir lista |
| POST | BASE/:id/tarefas/:item/mover | Mover ou reordenar cartão |
| POST | BASE/:id/despesas/:item/realizar | Converter prevista em realizada |
