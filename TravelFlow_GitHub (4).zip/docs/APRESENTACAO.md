# Apresentação (5 minutos)
Objetivo: organizar viagens e demonstrar banco relacional, MVC, CRUD, autenticação e segurança.

1. Cadastro/login: mostre o hash no MySQL (não revele a senha pessoal). Explique bcrypt e sessão.
2. Crie uma viagem: mostre as três listas automáticas, cadastre uma lista e um cartão.
3. Mova cartão, conclua e reabra. Crie etiqueta, associe ao cartão, escreva comentário.
4. Mostre roteiro, despesas e painel administrativo com dados reais.
5. Duas sessões: tente abrir a viagem de A com B; mostre que o acesso é negado. Mostre DER e organização MVC.

## Caminho pelos oito encontros
1. Requisitos, DER e wireframes (`docs`).
2. MySQL (`database/travelflow.sql`, `atualizacao_v2.sql`, `docs/CONSULTAS.sql`).
3. Express, Handlebars, CSS (`app.js`, `views`, `public`).
4. Sequelize (`config`, `models`).
5. CRUD de viagens (`controllers/viagensController.js`, `routes/viagens.js`).
6. Listas e cartões (`controllers/kanbanController.js`, `itensController.js`).
7. Helpers, etiquetas, comentários (`helpers`, `models`).
8. Login, sessão e entrega (`middlewares`, `routes/auth.js`, `test`).

MVC: navegador → rota Express → controller → model Sequelize → MySQL → controller → view Handlebars → navegador.
