# Requisitos do TravelFlow

## Funcionais

| Código | O sistema deve... |
|---|---|
| RF01 | Cadastrar usuários comuns com e-mail único, senha e confirmação. |
| RF02 | Autenticar, identificar perfil e encerrar sessão. |
| RF03 | Exibir destinos ativos na página inicial, pesquisar por nome, cidade, país ou região e filtrar categoria. |
| RF04 | Exibir indicadores administrativos reais e destinos mais escolhidos. |
| RF05 | Permitir que administrador liste, pesquise, crie, edite, ative, desative e exclua usuários comuns. |
| RF06 | Permitir que administrador cadastre, consulte, edite, desative e exclua destinos não vinculados a viagens. |
| RF07 | Permitir ao administrador listar, filtrar e gerenciar as viagens cadastradas. |
| RF08 | Permitir ao usuário criar, consultar, editar e excluir suas viagens. |
| RF09 | Organizar viagens em Kanban (Planejando, Em viagem e Concluída) e mover cartões. |
| RF10 | Cadastrar, consultar, editar, concluir, reabrir e excluir tarefas com prioridade e prazo. |
| RF11 | Destacar tarefas pendentes atrasadas. |
| RF12 | Criar, editar e excluir etiquetas coloridas, associando múltiplas etiquetas a uma tarefa. |
| RF13 | Adicionar e visualizar comentários nas tarefas. |
| RF14 | Criar, editar e excluir atividades do roteiro; exibi-las em ordem de data e horário. |
| RF15 | Cadastrar, editar e excluir despesas previstas/realizadas por categoria. |
| RF16 | Calcular orçamento, previsão, gastos realizados e saldo restante. |
| RF17 | Consultar e editar perfil próprio, exigindo senha atual. |
| RF18 | Exibir mensagens de sucesso e erro, confirmar exclusão e validar formulários. |

| RF19 | Criar três listas iniciais, adicionar, renomear e excluir listas, transferindo tarefas. |
| RF20 | Mover cartões entre listas, reordenar e atribuir responsável. |
| RF21 | Exibir detalhe e favoritar destinos, pesquisar por tema e orçamento. |
| RF22 | Exibir progresso, resumo financeiro, próximos eventos e relatórios CSV. |

## Correspondência com TaskFlow

| Apostila | TravelFlow |
|---|---|
| RF01–02 | RF01–02 |
| RF03–04 | RF08–09, RF19 |
| RF05–06 | RF10, RF19–20 |
| RF07–08 | RF10–11, RF20 |
| RF09–10 | RF12–13 |

## Não funcionais

| Código | Requisito |
|---|---|
| RNF01 | Usar Node.js, Express, JavaScript, HTML5, CSS3, Handlebars, MySQL e Sequelize; MVC e Database First. |
| RNF02 | Guardar senhas como hash bcrypt, nunca texto puro. |
| RNF03 | Gerenciar sessão com express-session e renovar ID no login. |
| RNF04 | Verificar autenticação, conta ativa, perfil e propriedade dos registros no servidor. |
| RNF05 | Usar consultas Sequelize parametrizadas, escapar HTML e validar entradas. |
| RNF06 | Exigir token CSRF nos POST, cookies HttpOnly e SameSite, e política de segurança de conteúdo. |
| RNF07 | Persistir dados em MySQL, com PK, FK, UNIQUE, regras de exclusão e DECIMAL monetário. |
| RNF08 | Interface responsiva, idioma português, datas brasileiras e moeda BRL. |
| RNF09 | Configurar ambiente por .env e funcionar localmente na porta 3000. |
| RNF10 | Documentar instalação, rotas, DER e testes; não realizar compras reais. |
