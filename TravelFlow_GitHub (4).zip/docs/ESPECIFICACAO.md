# Projeto TravelFlow | Sistema de Gerenciamento de Viagens

Desenvolva um sistema web completo chamado **TravelFlow**, destinado ao planejamento, organização e gerenciamento de viagens nacionais e internacionais.

O sistema deverá ser funcional, responsivo, moderno, intuitivo e possuir dois níveis de acesso: **Administrador e Usuário**.

Utilize como referência a estrutura da apostila do projeto TaskFlow da ETEC, adaptando suas funcionalidades para o tema de viagens.

## 1. Tecnologias obrigatórias

Utilize as seguintes tecnologias:

- Node.js
- Express.js
- JavaScript
- HTML5
- CSS3
- Handlebars
- MySQL
- Sequelize ORM
- Express-session
- Bcrypt
- XAMPP
- phpMyAdmin
- Arquitetura MVC (Model, View, Controller)
- Abordagem Database First

Não utilize React, Firebase ou Supabase. O sistema deverá funcionar localmente através do localhost:3000.

## 2. Identidade visual

Crie uma interface moderna, inspirada em plataformas de turismo e viagens.

Utilize:

- Azul-marinho.
- Azul-turquesa.
- Branco.
- Bege-claro.
- Detalhes em laranja.
- Fotografias de destinos turísticos.
- Ícones de aviões, malas, hotéis e mapas.
- Cards com cantos arredondados.
- Menu de navegação.
- Botões interativos.
- Layout responsivo para computadores e celulares.

Nome do sistema: TravelFlow.

Slogan: Sua próxima aventura começa aqui!

## 3. Tela inicial

A página inicial deverá apresentar:

- Logotipo TravelFlow.
- Menu de navegação.
- Banner principal com imagens de viagens.
- Destinos em destaque.
- Viagens nacionais e internacionais.
- Informações sobre o sistema.
- Barra de pesquisa de destinos.
- Botão de cadastro.
- Botão de login.
- Rodapé com informações de contato.

## 4. Cadastro e autenticação

Crie uma tela de cadastro contendo:

- Nome completo.
- E-mail.
- Senha.
- Confirmação de senha.
- Botão de cadastro.

Crie uma tela de login contendo:

- E-mail.
- Senha.
- Botão Entrar.
- Link para criar conta.
- Mensagem de erro para credenciais inválidas.

O sistema deverá identificar automaticamente se a conta pertence a um administrador ou a um usuário comum e direcioná-la ao painel correspondente.

Todos os cadastros públicos deverão receber o nível de usuário comum.

## 5. Painel do administrador

O administrador deverá possuir uma área exclusiva para gerenciamento do sistema.

### Dashboard administrativo

Apresentar indicadores reais do banco de dados:

- Total de usuários cadastrados.
- Total de destinos cadastrados.
- Total de viagens planejadas.
- Viagens pendentes.
- Viagens em andamento.
- Viagens concluídas.
- Destinos mais escolhidos.

### Gerenciamento de usuários

Permitir ao administrador:

- Visualizar usuários cadastrados.
- Pesquisar usuários.
- Cadastrar usuários.
- Editar informações.
- Ativar e desativar contas.
- Excluir usuários mediante confirmação.

### Gerenciamento de destinos

Permitir cadastrar, visualizar, editar e excluir destinos turísticos.

Cada destino deverá conter:

- Nome do destino.
- Cidade.
- Estado ou região.
- País.
- Descrição.
- Imagem ilustrativa.
- Categoria nacional ou internacional.
- Valor estimado da viagem.
- Principais atrações turísticas.
- Status ativo ou inativo.

### Gerenciamento de viagens

Permitir ao administrador:

- Visualizar todas as viagens cadastradas.
- Identificar o usuário responsável.
- Consultar datas e destinos.
- Acompanhar o status das viagens.
- Filtrar viagens por período e situação.
- Gerenciar registros quando necessário.

## 6. Painel do usuário

Após realizar o login, o usuário deverá acessar um painel personalizado com seu nome e suas informações.

O painel deverá conter:

- Mensagem de boas-vindas.
- Explorar destinos.
- Minhas viagens.
- Nova viagem.
- Meu roteiro.
- Meu perfil.
- Sair.

### Planejamento de viagens

O usuário deverá conseguir criar, visualizar, editar e excluir suas próprias viagens.

O formulário deverá conter:

- Título da viagem.
- Destino.
- Descrição.
- Data de ida.
- Data de retorno.
- Quantidade de viajantes.
- Orçamento disponível.
- Meio de transporte.
- Hospedagem.
- Observações.
- Status da viagem.

### Organização das viagens em Kanban

Utilize a mesma lógica de organização do TaskFlow, com três listas iniciais:

1. Planejando.
2. Em viagem.
3. Concluída.

Permita mover os cartões de viagens entre as listas utilizando botões de movimentação.

Cada cartão deverá apresentar o destino, as datas, o orçamento e a situação da viagem.

### Checklist de viagem

Permita criar, editar, concluir e excluir tarefas relacionadas à viagem, como:

- Comprar passagens.
- Reservar hospedagem.
- Organizar documentos.
- Preparar malas.
- Contratar seguro-viagem.
- Planejar passeios.
- Organizar transporte.
- Conferir orçamento.

Cada tarefa deverá possuir título, descrição, prioridade, prazo e status de conclusão.

Destaque tarefas atrasadas que ainda não foram concluídas.

### Roteiro de viagem

Permita organizar atividades por dia, contendo:

- Data.
- Horário.
- Local.
- Atividade.
- Valor estimado.
- Observações.

### Controle financeiro

Permita cadastrar despesas previstas e realizadas, separadas por categorias:

- Transporte.
- Hospedagem.
- Alimentação.
- Passeios.
- Compras.
- Outros gastos.

Apresente automaticamente o orçamento inicial, total previsto, total gasto e saldo restante.

### Etiquetas e comentários

Permita criar etiquetas coloridas para classificar as tarefas:

- Urgente.
- Documentação.
- Transporte.
- Hospedagem.
- Alimentação.
- Passeios.

Permita adicionar comentários e observações nas tarefas.

### Meu perfil

Permita ao usuário visualizar e editar:

- Nome.
- E-mail.
- Senha.

## 7. Banco de dados

Crie um banco de dados MySQL chamado `travelflow`.

Utilize a abordagem Database First, criando primeiro o banco e depois os models do Sequelize.

Crie as seguintes tabelas:

### usuarios

- id
- nome
- email
- senha
- tipo (admin ou usuario)
- ativo
- criado_em

### destinos

- id
- nome
- cidade
- estado
- pais
- descricao
- imagem
- categoria
- valor_estimado
- atracoes
- ativo

### viagens

- id
- usuario_id
- destino_id
- titulo
- descricao
- data_ida
- data_retorno
- quantidade_viajantes
- orcamento
- transporte
- hospedagem
- observacoes
- status
- criado_em

### tarefas

- id
- viagem_id
- titulo
- descricao
- prioridade
- data_entrega
- concluido

### roteiros

- id
- viagem_id
- data
- horario
- local
- atividade
- valor_estimado
- observacoes

### despesas

- id
- viagem_id
- descricao
- categoria
- valor
- data
- tipo (prevista ou realizada)

### etiquetas

- id
- viagem_id
- nome
- cor

### tarefa_etiqueta

- tarefa_id
- etiqueta_id

### comentarios

- id
- tarefa_id
- usuario_id
- texto
- criado_em

Defina corretamente as chaves primárias, chaves estrangeiras, relacionamentos 1:N e N:N, restrições UNIQUE e regras de exclusão.

Utilize DECIMAL para valores monetários.

Crie também o DER (Diagrama Entidade-Relacionamento) completo.

## 8. Estrutura de pastas

Organize o projeto da seguinte maneira:

- travelflow/
  - app.js
  - package.json
  - .env.example
  - config/
  - models/
  - controllers/
  - routes/
  - middlewares/
  - helpers/
  - views/
    - layouts/
    - partials/
    - auth/
    - admin/
    - usuario/
    - destinos/
    - viagens/
    - tarefas/
    - roteiros/
    - despesas/
  - public/
    - css/
    - js/
    - images/
  - database/
    - travelflow.sql
  - README.md

Separe corretamente as responsabilidades de cada arquivo utilizando a arquitetura MVC.

## 9. Rotas do sistema

Implemente as rotas utilizando GET para visualização e POST para operações que alteram os dados.

Inclua rotas para:

- Página inicial.
- Login.
- Cadastro.
- Logout.
- Dashboard administrativo.
- Gerenciamento de usuários.
- Gerenciamento de destinos.
- Minhas viagens.
- Criar viagem.
- Editar viagem.
- Excluir viagem.
- Alterar status.
- Gerenciar tarefas.
- Gerenciar roteiros.
- Gerenciar despesas.
- Gerenciar etiquetas.
- Adicionar comentários.
- Editar perfil.

Todas as rotas privadas deverão possuir autenticação e verificação de permissões.

## 10. Segurança

Implemente obrigatoriamente:

- Senhas criptograficamente protegidas por hash com bcrypt.
- Autenticação com express-session.
- Middleware de autenticação.
- Middleware de autorização administrativa.
- Proteção contra acesso não autorizado.
- Validação dos formulários no servidor.
- Proteção contra SQL Injection, XSS e CSRF.
- E-mail único para cada usuário.
- Confirmação antes de excluir registros.
- Variáveis de ambiente para credenciais do banco.
- Verificação de propriedade dos registros.
- Bloqueio de login para contas desativadas.

Um usuário comum não poderá visualizar, editar ou excluir viagens pertencentes a outro usuário, mesmo tentando acessar diretamente a URL.

O usuário comum também não poderá acessar páginas administrativas ou alterar seu próprio nível de permissão.

## 11. Contas e dados de teste

Crie um script de inicialização com senhas protegidas por bcrypt para gerar duas contas de demonstração:

**Administrador**

E-mail: admin@travelflow.com

Senha: Admin@123

**Usuário comum**

E-mail: usuario@travelflow.com

Senha: Usuario@123

Essas credenciais deverão ser utilizadas exclusivamente no ambiente local de demonstração.

Cadastre também destinos fictícios para testes, utilizando como exemplos:

- Paris.
- Londres.
- Nova York.
- Gramado.
- Rio de Janeiro.
- Fernando de Noronha.
- Cancún.
- Dubai.
- Orlando.

Identifique os valores apresentados como estimativas ilustrativas.

## 12. Requisitos de funcionamento

O sistema deverá possuir:

- CRUD completo.
- Integração real com MySQL.
- Login e logout funcionais.
- Diferenciação de permissões.
- Persistência dos dados.
- Mensagens de sucesso e erro.
- Pesquisa e filtros.
- Navegação funcional.
- Formulários validados.
- Layout responsivo.
- Formatação de datas no padrão brasileiro.
- Valores monetários em reais.
- Helpers do Handlebars.
- Código organizado e comentado.

Não crie apenas uma interface visual. Todos os botões, formulários, filtros e funcionalidades deverão estar conectados ao backend e ao banco de dados.

O sistema será destinado ao planejamento de viagens, sem realizar compras reais de passagens ou reservas de hotéis.

## 13. Entrega final

Entregue o projeto completo, incluindo:

- Código-fonte de todos os arquivos.
- Script SQL completo.
- DER.
- Requisitos funcionais e não funcionais numerados.
- Wireframes das principais telas.
- Tabela de rotas.
- Models.
- Controllers.
- Views.
- Middlewares.
- CSS.
- JavaScript.
- Arquivo package.json.
- README com instruções de instalação.
- Instruções para iniciar o MySQL pelo XAMPP.
- Instruções para importar o banco pelo phpMyAdmin.
- Comandos para instalar as dependências.
- Instruções para executar o servidor.
- Checklist de testes das funcionalidades.

Desenvolva o projeto por etapas, indicando o nome e a localização de cada arquivo. Utilize códigos completos, sem omitir trechos necessários para o funcionamento.

Mantenha a complexidade adequada a um projeto escolar do segundo ano de Informática da ETEC, seguindo a metodologia apresentada na apostila TaskFlow.
