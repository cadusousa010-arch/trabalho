USE travelflow;
SELECT v.titulo,l.titulo AS lista,t.titulo AS tarefa,u.nome AS responsavel
FROM viagens v JOIN listas_viagem l ON l.viagem_id=v.id LEFT JOIN tarefas t ON t.lista_id=l.id LEFT JOIN usuarios u ON u.id=t.responsavel_id ORDER BY v.id,l.posicao,t.posicao;
SELECT t.titulo,e.nome FROM tarefas t JOIN tarefa_etiqueta te ON te.tarefa_id=t.id JOIN etiquetas e ON e.id=te.etiqueta_id;
SELECT v.titulo,v.orcamento,COALESCE(SUM(CASE WHEN d.tipo='realizada' THEN d.valor ELSE 0 END),0) AS gasto FROM viagens v LEFT JOIN despesas d ON d.viagem_id=v.id GROUP BY v.id,v.titulo,v.orcamento;
SELECT d.nome,COUNT(v.id) AS total FROM destinos d LEFT JOIN viagens v ON v.destino_id=d.id GROUP BY d.id,d.nome ORDER BY total DESC;
