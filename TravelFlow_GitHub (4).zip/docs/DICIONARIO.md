# Dicionário de dados
A definição física integral, com tipos, campos obrigatórios e valores padrão, está em `database/travelflow.sql`. O DER visual inclui todos os atributos.

| Tabela | Campos e finalidade |
|---|---|
| usuarios | id, nome, email único, senha (hash), tipo, ativo, criado_em |
| destinos | id, nome, cidade, estado, pais, descricao, imagem, categoria, valor_estimado DECIMAL(12,2), atracoes, ativo, tema |
| viagens | id, usuario_id, destino_id, titulo, descricao, data_ida, data_retorno, quantidade_viajantes, orcamento DECIMAL(12,2), transporte, hospedagem, observacoes, status, criado_em |
| listas_viagem | id, viagem_id, titulo VARCHAR(100), posicao INT, etapa ENUM aberta/concluida |
| tarefas | id, viagem_id, titulo, descricao, prioridade, data_entrega, concluido, lista_id, posicao, responsavel_id opcional |
| roteiros | id, viagem_id, data, horario, local, atividade, valor_estimado DECIMAL(12,2), observacoes |
| despesas | id, viagem_id, descricao, categoria, valor DECIMAL(12,2), data, tipo prevista/realizada |
| etiquetas | id, viagem_id, nome, cor CHAR(7); nome único por viagem |
| tarefa_etiqueta | tarefa_id + etiqueta_id, PK composta |
| comentarios | id, tarefa_id, usuario_id, texto, criado_em |
| favoritos | usuario_id + destino_id, PK composta |

Regras: FK e verificações de propriedade no servidor; lista e tarefa precisam pertencer à mesma viagem. A etapa da lista controla conclusão. Não se exclui a última lista aberta nem a lista de conclusão. Responsável pode ser proprietário ou nulo. Valores monetários não negativos.
