# DER: TravelFlow

Abra `der.svg` no navegador para visualizar todas as tabelas e colunas. O SQL em `database/travelflow.sql` é a definição física do banco.

| Entidade pai | Entidade filha | Cardinalidade | Chave estrangeira | Exclusão |
|---|---|---|---|---|
| usuarios | viagens | 1:N | viagens.usuario_id | CASCADE |
| destinos | viagens | 1:N | viagens.destino_id | RESTRICT |
| viagens | tarefas | 1:N | tarefas.viagem_id | CASCADE |
| viagens | roteiros | 1:N | roteiros.viagem_id | CASCADE |
| viagens | despesas | 1:N | despesas.viagem_id | CASCADE |
| viagens | etiquetas | 1:N | etiquetas.viagem_id | CASCADE |
| tarefas | tarefa_etiqueta | 1:N | tarefa_etiqueta.tarefa_id | CASCADE |
| etiquetas | tarefa_etiqueta | 1:N | tarefa_etiqueta.etiqueta_id | CASCADE |
| tarefas | comentarios | 1:N | comentarios.tarefa_id | CASCADE |
| usuarios | comentarios | 1:N | comentarios.usuario_id | CASCADE |

Tarefas e etiquetas têm relacionamento N:N por meio de `tarefa_etiqueta`, com PK composta. O controller verifica que tarefa e etiqueta pertencem à mesma viagem. Um destino já utilizado não pode ser excluído para preservar as viagens. UNIQUE em `usuarios.email`, `destinos(nome,cidade,pais)` e `etiquetas(viagem_id,nome)`.

## Novos relacionamentos na versão 2

| Pai | Filho | Cardinalidade | FK | Exclusão |
|---|---|---|---|---|
| viagens | listas_viagem | 1:N | viagem_id | CASCADE |
| listas_viagem | tarefas | 1:N | lista_id | SET NULL (interface exige transferência) |
| usuarios | tarefas | 1:N | responsavel_id | SET NULL |
| usuarios | favoritos | 1:N | usuario_id | CASCADE |
| destinos | favoritos | 1:N | destino_id | CASCADE |

Favoritos tem PK composta (usuario_id, destino_id). O Kanban geral usa viagens.status; cada viagem também contém listas editáveis e cartões de tarefas. A lista de conclusão e ao menos uma lista aberta são mantidas para preservar o fluxo de reabertura. Há 11 tabelas.
