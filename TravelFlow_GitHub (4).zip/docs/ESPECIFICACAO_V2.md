# ATUALIZAÇÃO COMPLETA DO PROJETO TRAVELFLOW 2.0

Atue como um desenvolvedor Full Stack sênior, especialista em Node.js, Express, MySQL, Sequelize, Handlebars, JavaScript, UI/UX e arquitetura MVC.

Sua missão é analisar, corrigir, modernizar e ampliar completamente o projeto TravelFlow existente.

O sistema é um trabalho escolar do segundo ano de Informática da ETEC, baseado na Apostila do Aluno TaskFlow da ETEC de Campo Limpo Paulista, adaptado para o tema de viagens.

Não quero apenas sugestões ou exemplos de código. Quero que você analise todos os arquivos existentes e implemente diretamente as alterações necessárias no projeto.

O resultado deverá ser um sistema completo, moderno, bonito, profissional, responsivo e funcional, com integração real ao banco de dados.

## 1. Regras obrigatórias

Mantenha as tecnologias utilizadas no projeto original:

- Node.js.
- Express.js.
- JavaScript.
- HTML5.
- CSS3.
- Handlebars.
- MySQL.
- Sequelize ORM.
- Express-session.
- Bcrypt.
- XAMPP.
- phpMyAdmin.
- Arquitetura MVC.
- Metodologia Database First.

Não utilize React, Next.js, Firebase, Supabase ou outro banco de dados.

O sistema já está funcionando em localhost:3000.

Preserve o banco de dados existente, os usuários cadastrados, os destinos, as viagens e as configurações do arquivo .env.

Não apague o banco de dados e não recrie o projeto desnecessariamente.

Caso sejam necessárias novas tabelas ou colunas, crie scripts SQL de atualização separados, seguros e compatíveis com o MySQL/MariaDB do XAMPP.

## 2. Correção completa dos erros existentes

Analise todos os arquivos, incluindo controllers, routes, models, middlewares, helpers, views e arquivos JavaScript.

### Erro dos formulários

Atualmente, os formulários apresentam a mensagem [object Object] no lugar dos nomes dos campos.

Verifique especialmente:

- helpers/handlebars.js
- helpers/forms.js
- views/partials/fields.handlebars
- Todos os formulários de login, cadastro, viagens, destinos, usuários, perfil, despesas e tarefas.

Existe um possível conflito entre o helper chamado label e a propriedade label dos objetos utilizados nos formulários.

Corrija a referência dos campos utilizando this.label quando apropriado ou renomeando o helper para evitar o conflito. Caso renomeie o helper, atualize todas as suas referências no projeto.

Os campos de cadastro devem apresentar corretamente:

- Nome completo.
- E-mail.
- Senha.
- Confirmar senha.

Corrija também os nomes das opções dos campos select.

Implemente testes de renderização dos formulários para garantir que a expressão [object Object] não apareça em nenhuma página.

### Erro das imagens

Atualmente, vários destinos aparecem com a mesma imagem genérica de montanhas.

Corrija esse problema completamente.

Cada destino deverá possuir uma fotografia correspondente ao local.

Armazene preferencialmente as fotografias em public/images/destinos.

Utilize imagens reais com licença apropriada para utilização no projeto, mantendo os créditos quando necessários.

Não utilize imagens genéricas repetidas, links quebrados ou fotografias que não correspondam ao destino.

Atualize os destinos que já existem no banco. O script seed atual utiliza findOrCreate, portanto apenas alterar os dados de criação não atualizará automaticamente os registros existentes.

Crie um script específico e seguro para atualizar as imagens cadastradas, sem apagar os demais dados.

Caso não seja possível obter as fotografias automaticamente, informe quais arquivos precisam ser adicionados manualmente.

## 3. Nova identidade visual

Transforme o TravelFlow em uma plataforma de viagens moderna, inspirada na qualidade visual de grandes sites de turismo, sem copiar suas marcas ou interfaces.

Nome: TravelFlow.

Slogan: Sua próxima aventura começa aqui!

Utilize a seguinte paleta:

- Azul-marinho: #0F2942.
- Azul-turquesa: #0D9488.
- Azul-claro: #E0F2FE.
- Branco: #FFFFFF.
- Bege-claro: #F8F5EF.
- Laranja: #F59E0B.
- Cinza suave: #64748B.

Utilize tipografia moderna, preferencialmente Poppins ou Inter, com alternativas locais caso não haja internet.

Implemente:

- Logotipo moderno com símbolo de avião.
- Menu de navegação elegante.
- Fotografias de alta qualidade.
- Ícones profissionais e consistentes.
- Cards com cantos arredondados.
- Sombras suaves.
- Animações discretas.
- Transições suaves.
- Botões com efeito hover.
- Indicadores visuais de carregamento quando necessários.
- Mensagens de sucesso e erro.
- Estados vazios personalizados.
- Janelas de confirmação.
- Layout totalmente responsivo.

Evite telas vazias, espaços mal aproveitados, elementos desalinhados, formulários excessivamente grandes e aparência de template básico.

Todas as páginas devem utilizar a mesma identidade visual.

## 4. Reformulação da página inicial

Crie uma página inicial completa, visualmente atrativa e profissional.

### Cabeçalho

Inclua:

- Logotipo TravelFlow.
- Início.
- Destinos nacionais.
- Destinos internacionais.
- Como funciona.
- Sobre.
- Entrar.
- Criar conta.

O cabeçalho deverá ser responsivo, com menu adaptado para celulares.

### Banner principal

Crie um banner amplo com fotografia de um destino turístico, utilizando boa resolução e uma camada de contraste para facilitar a leitura.

Texto principal:

O mundo está esperando por você.

Texto complementar:

Descubra novos destinos, organize seus roteiros e transforme seus planos em experiências inesquecíveis.

Botões:

- Explorar destinos.
- Planejar minha viagem.

### Pesquisa de destinos

Crie uma área de pesquisa visualmente destacada com:

- Destino, cidade ou país.
- Categoria nacional ou internacional.
- Faixa de orçamento.
- Botão pesquisar.
- Botão limpar filtros.

Todos os filtros devem consultar os dados reais do banco.

### Destinos em destaque

Apresente cards modernos com:

- Fotografia real.
- Nome do destino.
- Cidade e país.
- Categoria.
- Descrição resumida.
- Principais atrações.
- Valor estimado.
- Botão Ver detalhes.
- Botão Planejar viagem.

As informações e os valores devem vir do MySQL.

Identifique os valores como estimativas ilustrativas, não como ofertas comerciais reais.

### Categorias de destinos

Crie categorias como:

- Praias.
- Montanhas.
- Grandes cidades.
- Natureza.
- Destinos românticos.
- Viagens em família.
- Aventura.
- Cultura e história.

Caso necessário, adicione essas classificações ao banco por meio de um script de atualização.

### Como funciona

Apresente quatro etapas com ícones:

1. Escolha seu destino.
2. Planeje sua viagem.
3. Organize seu roteiro e orçamento.
4. Aproveite sua próxima aventura.

### Rodapé

Inclua:

- Informações sobre o TravelFlow.
- Links rápidos.
- Contato.
- Identificação como projeto educacional.
- Direitos reservados.
- Aviso de que o sistema não realiza reservas ou compras reais.

Não invente avaliações, depoimentos ou números de clientes.

## 5. Destinos turísticos

Cadastre ou atualize pelo menos 20 destinos de demonstração, com fotografias diferentes, informações e atrações correspondentes.

### Destinos nacionais

- Rio de Janeiro.
- Gramado.
- Fernando de Noronha.
- Porto de Galinhas.
- Maragogi.
- Salvador.
- Florianópolis.
- Foz do Iguaçu.
- Bonito.
- Campos do Jordão.

### Destinos internacionais

- Paris.
- Londres.
- Nova York.
- Dubai.
- Cancún.
- Orlando.
- Roma.
- Lisboa.
- Buenos Aires.
- Maldivas.

Cada destino deverá possuir uma página própria contendo:

- Banner fotográfico.
- Galeria de imagens, quando disponível.
- Nome.
- País e região.
- Descrição completa.
- Principais atrações turísticas.
- Categoria.
- Orçamento estimado.
- Sugestões gerais de atividades.
- Botão para planejar viagem.

Não invente preços atuais de passagens, hospedagens ou informações que dependam de consulta em tempo real.

## 6. Tela de login

Crie uma tela profissional dividida em duas áreas no computador.

Uma área deverá possuir uma fotografia de viagem e uma frase inspiradora.

A outra deverá conter o formulário de acesso:

- Logotipo.
- E-mail.
- Senha.
- Mostrar ou ocultar senha.
- Botão Entrar.
- Link Criar conta.
- Link Voltar para o início.

Adapte o layout para celulares.

Apresente mensagens claras em casos de credenciais incorretas ou contas desativadas.

O sistema deverá identificar automaticamente o tipo da conta e redirecionar para o painel correspondente.

Não permita que o usuário escolha ser administrador durante o cadastro.

## 7. Tela de cadastro

Crie um formulário moderno com:

- Nome completo.
- E-mail.
- Senha.
- Confirmação de senha.
- Indicador dos requisitos da senha.
- Opção de mostrar ou ocultar senha.
- Botão Criar minha conta.
- Link para login.

Valide os dados no frontend e obrigatoriamente no backend.

Não permita:

- E-mails duplicados.
- E-mails inválidos.
- Senhas menores que oito caracteres.
- Senhas diferentes da confirmação.
- Campos obrigatórios vazios.

Nunca apresente novamente a senha digitada após um erro de formulário.

Utilize bcrypt para proteger as senhas com hash.

## 8. Painel completo do usuário

Crie um dashboard profissional com menu lateral responsivo.

Menu:

- Visão geral.
- Explorar destinos.
- Minhas viagens.
- Nova viagem.
- Meu roteiro.
- Checklist.
- Minhas despesas.
- Destinos favoritos.
- Meu perfil.
- Sair.

Implemente uma página inicial personalizada com o nome do usuário.

Apresente indicadores reais:

- Total de viagens.
- Viagens em planejamento.
- Viagens em andamento.
- Viagens concluídas.
- Próxima viagem.
- Orçamento total das viagens.
- Tarefas pendentes.
- Tarefas concluídas.

Inclua:

- Contagem regressiva para a próxima viagem.
- Progresso de preparação.
- Próximas atividades.
- Resumo financeiro.
- Destinos recomendados com base nas categorias disponíveis.
- Acesso rápido para criar uma viagem.

Todos os indicadores devem utilizar dados reais do banco relacionados ao usuário autenticado.

## 9. Gerenciamento de viagens

Implemente CRUD completo.

O usuário deverá conseguir criar, visualizar, editar e excluir suas próprias viagens.

Campos:

- Título da viagem.
- Destino.
- Descrição.
- Data de ida.
- Data de retorno.
- Quantidade de viajantes.
- Orçamento.
- Meio de transporte.
- Hospedagem.
- Observações.
- Status.

Valide datas, valores e quantidade de viajantes.

A data de retorno não pode ser anterior à data de ida.

Cada viagem deverá possuir uma página detalhada com:

- Fotografia do destino.
- Período da viagem.
- Número de viajantes.
- Dias restantes.
- Orçamento disponível.
- Progresso das tarefas.
- Roteiro.
- Checklist.
- Despesas.
- Etiquetas.
- Observações.

## 10. Kanban de viagens e tarefas

Esta funcionalidade é essencial para atender à apostila TaskFlow.

Implemente dois níveis de organização.

### Kanban geral de viagens

Organize as viagens em três colunas:

- Planejando.
- Em viagem.
- Concluída.

Permita movimentar os cartões utilizando botões de direção.

Implemente arrastar e soltar como melhoria opcional, mantendo os botões de movimentação funcionais.

Toda alteração deve ser salva no MySQL.

### Kanban interno de cada viagem

Cada viagem deverá funcionar como um quadro do TaskFlow.

Ao criar uma viagem, crie automaticamente três listas:

- A fazer.
- Fazendo.
- Concluído.

Permita ao usuário:

- Criar novas listas.
- Renomear listas.
- Excluir listas mediante confirmação.
- Criar cartões de tarefas dentro das listas.
- Mover cartões para a esquerda e para a direita.
- Alterar a posição dos cartões.
- Editar cartões.
- Concluir tarefas.
- Reabrir tarefas.
- Excluir cartões.

Crie uma tabela listas_viagem, caso ainda não exista uma estrutura equivalente, contendo id, viagem_id, titulo e posicao.

Atualize a tabela tarefas com lista_id, posicao e responsavel_id.

Preserve todas as tarefas existentes durante a atualização. Vincule as tarefas concluídas à lista Concluído e as demais à lista A fazer.

O responsável poderá ser o proprietário da viagem ou ficar sem responsável. Caso seja implementado compartilhamento entre usuários, utilize permissões explícitas, sem permitir acesso automático de terceiros.

Ao excluir uma lista com tarefas, solicite confirmação e ofereça a opção de transferir os cartões para outra lista antes da exclusão.

Implemente transações nas operações que alteram várias tabelas simultaneamente.

## 11. Checklist de viagem

Crie tarefas personalizadas ou disponibilize sugestões de checklist:

- Comprar passagens.
- Reservar hospedagem.
- Organizar documentos.
- Conferir passaporte.
- Preparar malas.
- Contratar seguro-viagem.
- Planejar passeios.
- Organizar transporte.
- Conferir orçamento.
- Separar medicamentos.
- Conferir reservas.

Cada tarefa deverá possuir:

- Título.
- Descrição.
- Prioridade baixa, média ou alta.
- Prazo.
- Responsável.
- Lista.
- Posição.
- Status de conclusão.
- Etiquetas.
- Comentários.

Destaque tarefas atrasadas em vermelho.

Apresente uma barra de progresso calculada pela quantidade real de tarefas concluídas.

Sincronize o checklist com o Kanban para que ambos utilizem os mesmos registros.

## 12. Roteiro de viagem

Crie uma interface organizada por dias, utilizando uma linha do tempo visual.

Permita cadastrar:

- Data.
- Horário.
- Atividade.
- Local.
- Valor estimado.
- Observações.

Permita visualizar, editar e excluir atividades.

Organize automaticamente os registros por data e horário.

Valide se as atividades estão dentro do período da viagem.

Apresente o total estimado de atividades de cada dia.

## 13. Controle financeiro

Crie uma área financeira completa para cada viagem.

Indicadores:

- Orçamento inicial.
- Total de despesas previstas.
- Total de despesas realizadas.
- Saldo disponível.
- Percentual do orçamento utilizado.

Categorias:

- Transporte.
- Hospedagem.
- Alimentação.
- Passeios.
- Compras.
- Seguro-viagem.
- Outros gastos.

Implemente:

- Cadastro de despesas.
- Edição.
- Exclusão.
- Filtros por categoria.
- Filtros por período.
- Conversão de despesa prevista em realizada.
- Gráfico de despesas por categoria.
- Barra de utilização do orçamento.
- Alerta ao ultrapassar o orçamento.

Utilize valores reais registrados no MySQL.

Não some despesas previstas e realizadas como se ambas já tivessem sido pagas.

Utilize DECIMAL no banco de dados para valores monetários e formatação em reais.

## 14. Etiquetas e comentários

Implemente o relacionamento N:N entre tarefas e etiquetas, conforme a metodologia da apostila.

Permita:

- Criar etiquetas.
- Escolher cores.
- Editar etiquetas.
- Excluir etiquetas.
- Associar múltiplas etiquetas a uma tarefa.
- Remover etiquetas de uma tarefa.

Sugestões:

- Urgente.
- Documentação.
- Transporte.
- Hospedagem.
- Alimentação.
- Passeios.

Cada comentário deverá apresentar:

- Nome do autor.
- Texto.
- Data.
- Horário.

Verifique as permissões do usuário antes de permitir qualquer alteração.

## 15. Destinos favoritos

Implemente a opção de favoritar destinos utilizando um ícone de coração.

Crie uma tabela favoritos com relacionamento entre usuários e destinos, caso necessário.

Impeça registros duplicados.

Disponibilize uma página exclusiva para consultar e remover os destinos favoritos.

## 16. Painel administrativo completo

Crie uma interface administrativa profissional, separada da área do usuário comum.

Utilize menu lateral, cards de indicadores, tabelas modernas e gráficos.

Menu:

- Dashboard.
- Usuários.
- Destinos.
- Viagens.
- Tarefas.
- Relatórios.
- Meu perfil.
- Sair.

### Dashboard administrativo

Apresente informações reais:

- Total de usuários.
- Usuários ativos.
- Usuários inativos.
- Total de destinos.
- Destinos nacionais.
- Destinos internacionais.
- Total de viagens.
- Viagens por situação.
- Destinos mais escolhidos.
- Cadastros recentes.

Adicione gráficos para:

- Viagens por mês.
- Distribuição por status.
- Destinos mais planejados.
- Crescimento dos cadastros.

Não utilize números fixos ou dados fictícios nos indicadores.

### Gerenciamento de usuários

Permita:

- Listar usuários.
- Pesquisar por nome ou e-mail.
- Cadastrar usuários comuns.
- Editar informações.
- Ativar contas.
- Desativar contas.
- Excluir usuários mediante confirmação.
- Filtrar usuários por situação.
- Visualizar viagens vinculadas.

Nunca exiba hashes ou senhas na interface administrativa.

Proteja a conta administrativa principal contra exclusão ou desativação acidental.

### Gerenciamento de destinos

Permita:

- Cadastrar destinos.
- Editar destinos.
- Excluir destinos quando não houver vínculos impeditivos.
- Ativar e desativar destinos.
- Cadastrar imagens.
- Atualizar informações e estimativas.
- Pesquisar e filtrar destinos.

Implemente uma prévia da fotografia.

Se implementar upload de imagens, valide o formato, tamanho e conteúdo do arquivo e utilize nomes seguros.

### Gerenciamento de viagens

Permita consultar todas as viagens cadastradas.

Apresente:

- Usuário responsável.
- Destino.
- Período.
- Quantidade de viajantes.
- Orçamento.
- Status.

Permita pesquisar, filtrar e gerenciar registros de acordo com as permissões administrativas.

### Relatórios

Crie relatórios simples sobre:

- Usuários cadastrados.
- Viagens por período.
- Destinos mais escolhidos.
- Viagens por situação.

Disponibilize filtros e opção de exportação CSV.

## 17. Meu perfil

Crie uma página de perfil moderna, permitindo:

- Visualizar nome e e-mail.
- Editar dados pessoais.
- Alterar senha.
- Visualizar o tipo de conta.

Solicite a senha atual para alterações sensíveis.

O usuário comum não poderá modificar o próprio nível de acesso.

## 18. Banco de dados

Preserve as tabelas existentes:

- usuarios.
- destinos.
- viagens.
- tarefas.
- roteiros.
- despesas.
- etiquetas.
- tarefa_etiqueta.
- comentarios.

Adicione, quando necessário:

- listas_viagem.
- favoritos.
- galeria_destinos.

Defina corretamente:

- Chaves primárias.
- Chaves estrangeiras.
- Relacionamentos 1:N.
- Relacionamentos N:N.
- Restrições UNIQUE.
- Índices.
- Campos obrigatórios.
- Regras de exclusão CASCADE, RESTRICT e SET NULL, conforme cada relacionamento.

Utilize transações nas operações que exigem consistência entre tabelas.

Mantenha a metodologia Database First.

Crie primeiro os scripts SQL e depois adapte os models e associações do Sequelize.

Não utilize sequelize.sync com force ou alter no banco existente.

Crie um arquivo database/atualizacao_v2.sql para a atualização dos registros atuais.

O script deve preservar os dados e verificar se as alterações já foram aplicadas antes de executá-las novamente.

Atualize também o arquivo database/travelflow.sql para instalações novas.

Documente a necessidade de realizar backup antes da atualização.

## 19. Segurança

Revise toda a segurança da aplicação.

Implemente ou preserve:

- Hash de senhas com bcrypt.
- Sessões com express-session.
- Middleware de autenticação.
- Middleware de autorização administrativa.
- Proteção CSRF.
- Proteção contra SQL Injection.
- Proteção contra XSS.
- Validação de formulários no servidor.
- Controle de propriedade dos registros.
- Bloqueio de contas inativas.
- Limitação de tentativas de login.
- Cookies com HttpOnly e SameSite.
- Variáveis de ambiente.
- Confirmação de exclusões.

Não desative a política de segurança do navegador apenas para carregar imagens, ícones ou bibliotecas.

Nunca permita que usuários comuns acessem viagens, tarefas, etiquetas, comentários ou despesas de outros usuários por meio da alteração manual de URLs ou parâmetros.

Não exponha credenciais, tokens de sessão ou informações internas do servidor.

## 20. Rotas e funcionamento

Mantenha a estrutura MVC e as rotas existentes sempre que possível.

Utilize GET para visualizar páginas e POST para criar, editar, excluir ou movimentar registros, conforme a metodologia da apostila.

Revise todos os botões, links e formulários.

Não deixe:

- Botões sem funcionalidade.
- Links com destinos inexistentes.
- Erros 404 desnecessários.
- Erros 500 durante operações válidas.
- Dados fixos simulando informações do banco.
- Formulários com [object Object].
- Imagens quebradas.
- Páginas administrativas acessíveis sem autorização.

Implemente páginas de erro 403, 404 e 500 com a identidade visual do TravelFlow.

## 21. Estrutura de arquivos

Mantenha o projeto organizado nas seguintes pastas:

- config/
- models/
- controllers/
- routes/
- middlewares/
- helpers/
- views/
- views/layouts/
- views/partials/
- views/auth/
- views/admin/
- views/usuario/
- views/destinos/
- views/viagens/
- views/tarefas/
- views/roteiros/
- views/despesas/
- public/css/
- public/js/
- public/images/
- database/
- docs/
- test/

Separe adequadamente as responsabilidades de cada arquivo.

Evite concentrar toda a aplicação no app.js.

Utilize componentes reutilizáveis do Handlebars para os menus, formulários, mensagens, cards e demais elementos compartilhados.

## 22. Atendimento obrigatório à apostila TaskFlow

O sistema deverá atender a todos os requisitos funcionais RF01 a RF10 da apostila:

RF01: Cadastro de usuário com nome, e-mail único e senha.

RF02: Login e logout.

RF03: Listar, criar, editar e excluir quadros do usuário, adaptados para viagens.

RF04: Abrir um quadro de viagem e visualizar listas e cartões lado a lado.

RF05: Criar e excluir listas, com três listas iniciais automáticas em cada viagem.

RF06: Criar, editar, concluir, reabrir, mover e excluir cartões de tarefas.

RF07: Definir prioridade, data de entrega e responsável.

RF08: Destacar tarefas atrasadas.

RF09: Criar etiquetas coloridas e associá-las aos cartões.

RF10: Adicionar comentários aos cartões.

Não substitua os requisitos obrigatórios da apostila apenas por funcionalidades adicionais de turismo.

As funcionalidades administrativas, financeiras e de roteiro são complementos do TravelFlow.

## 23. Documentação escolar

Atualize todos os documentos existentes na pasta docs.

Entregue:

- Descrição do projeto.
- Objetivo geral.
- Objetivos específicos.
- Requisitos funcionais numerados.
- Requisitos não funcionais numerados.
- Regras de negócio.
- DER completo e atualizado.
- Dicionário de dados.
- Chaves primárias e estrangeiras.
- Cardinalidades.
- Diagrama de funcionamento MVC.
- Tabela completa de rotas.
- Wireframes.
- Consultas SQL demonstrativas.
- Checklist de testes.
- Manual de instalação.
- Manual do usuário.
- Manual do administrador.

Organize também a documentação conforme os oito encontros da apostila:

1. Desenho do sistema.
2. Banco de dados MySQL.
3. Express, Handlebars e CSS.
4. Sequelize e models.
5. CRUD e Kanban.
6. Listas e cartões.
7. Helpers, etiquetas e comentários.
8. Login, sessão e entrega final.

Inclua um roteiro de apresentação de cinco minutos para demonstrar o funcionamento ao professor.

## 24. Testes obrigatórios

Execute testes de sintaxe em todos os arquivos JavaScript.

Execute npm test e acrescente testes quando necessário.

Teste:

- Cadastro.
- Login.
- Logout.
- Validação de senhas.
- E-mail duplicado.
- Login administrativo.
- Login de usuário comum.
- Cadastro de destinos.
- Carregamento das fotografias.
- Pesquisa e filtros.
- Criação de viagens.
- Edição de viagens.
- Exclusão de viagens.
- Criação automática das três listas.
- Criação e exclusão de listas.
- Movimentação de cartões.
- Conclusão e reabertura de tarefas.
- Etiquetas.
- Comentários.
- Roteiros.
- Despesas.
- Favoritos.
- Alteração de perfil.
- Permissões administrativas.
- Isolamento dos registros entre usuários.
- Persistência dos dados após reiniciar o servidor.
- Responsividade em celulares e computadores.

Teste a segurança utilizando duas sessões diferentes e tentando acessar registros de outro usuário.

Revise os avisos de vulnerabilidades das dependências sem utilizar npm audit fix --force automaticamente.

Não declare uma funcionalidade como testada caso não tenha sido possível executá-la.

## 25. Contas de demonstração

Preserve as contas existentes:

Administrador:

E-mail: admin@travelflow.com

Senha inicial de demonstração: Admin@123

Usuário:

E-mail: usuario@travelflow.com

Senha inicial de demonstração: Usuario@123

Essas credenciais são exclusivas do ambiente local de demonstração.

Não redefina automaticamente senhas que já tenham sido alteradas.

## 26. Entrega final

Antes de começar, analise toda a estrutura existente e identifique os erros, funcionalidades ausentes e requisitos que precisam ser implementados.

Faça as alterações diretamente nos arquivos do projeto.

Priorize primeiro a correção dos erros, a preservação do banco e os requisitos obrigatórios da apostila. Depois implemente a modernização visual e as funcionalidades complementares.

Não entregue apenas uma demonstração visual.

Não utilize pseudocódigo, trechos incompletos, funções vazias ou botões decorativos.

Mantenha a complexidade adequada a um estudante do segundo ano de Informática, com código organizado e comentários explicativos.

Ao finalizar, apresente:

- Erros encontrados e corrigidos.
- Funcionalidades implementadas.
- Arquivos criados.
- Arquivos modificados.
- Alterações necessárias no MySQL.
- Dependências adicionais, se houver.
- Resultado dos testes.
- Limitações encontradas.
- Comandos exatos para atualizar e executar o projeto no Windows.

O resultado final deverá ser o TravelFlow 2.0: um sistema de gerenciamento de viagens bonito, moderno, completo, seguro e funcional, com aparência profissional e todos os requisitos obrigatórios da apostila TaskFlow atendidos.