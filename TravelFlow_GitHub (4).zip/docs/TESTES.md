# Checklist para validação local

Marque após executar no XAMPP. Estes testes manuais não foram executados no ambiente de geração.

- [ ] Importar SQL e conferir as 11 tabelas e suas FKs no phpMyAdmin.
- [ ] Executar `npm run seed`: conferir 2 usuários, 20 destinos e senhas armazenadas como hash.
- [ ] Abrir `/`, pesquisar Paris, filtrar nacionais e internacionais.
- [ ] Criar conta comum; confirmar que e-mail repetido é recusado.
- [ ] Tentar senha errada; conferir aviso de erro; entrar com conta correta; sair.
- [ ] Entrar como admin; conferir indicadores, criar/editar/desativar usuário e tentar login na conta desativada.
- [ ] Cadastrar destino, editar, desativar; verificar que não aparece no catálogo público. Excluir destino sem vínculo.
- [ ] Entrar como usuário, criar viagem com datas válidas, editar; recusar retorno anterior à ida.
- [ ] Mover cartão entre Planejando, Em viagem e Concluída; atualizar a página e conferir persistência.
- [ ] Criar tarefa com data anterior a hoje e conferir atraso; concluir e reabrir; editar.
- [ ] Criar duas etiquetas, marcar ambas em uma tarefa, atualizar página; editar/excluir etiqueta.
- [ ] Adicionar comentário contendo `<script>alert(1)</script>`; conferir que aparece como texto e não executa.
- [ ] Criar atividade no roteiro; editar, ordenar por data/horário; recusar data fora da viagem; excluir.
- [ ] Definir orçamento de R$ 1.000,00, criar despesa prevista R$ 200,00 e realizada R$ 150,00; verificar saldo R$ 850,00. Editar e excluir despesas.
- [ ] Alterar perfil com senha atual; recusar senha atual incorreta; confirmar nova senha e login.
- [ ] Criar duas contas comuns, copiar URL de viagem/tarefa de A, entrar como B e tentar abrir ou editar; conferir 404 ou ausência de alteração. Testar também IDs de etiqueta de outra viagem.
- [ ] Entrar como usuário e tentar `/admin`; conferir 403. Enviar um POST sem token CSRF; conferir 403. Verificar que GET nunca exclui registros.
- [ ] Entrar como admin, filtrar viagens por período/situação e alterar viagem; conferir indicadores atualizados.
- [ ] Tentar excluir destino associado a viagem; conferir recusa. Desativar em vez de excluir.
- [ ] Excluir viagem; conferir confirmação, exclusão de tarefas, roteiro, etiquetas, comentários e despesas no MySQL.
- [ ] Reiniciar Node; entrar novamente e verificar que dados permanecem.
- [ ] Redimensionar navegador para 375 px; verificar navegação, formulário, cards e Kanban.

- [ ] Após migração, verificar se todas as tarefas antigas foram preservadas e possuem lista. Repetir atualização e verificar ausência de duplicatas.
- [ ] Criar viagem e verificar três listas; adicionar, renomear, excluir lista vazia e transferir tarefas de lista preenchida.
- [ ] Mover cartão entre listas e reordenar na mesma lista; verificar conclusão e reabertura sincronizadas.
- [ ] Atribuir responsável, editar e remover; testar lista ou responsável de outra viagem.
- [ ] Verificar que rótulos e selects não mostram [object Object].
- [ ] Executar npm run fotos, revisar todas as fotos e créditos; testar fotos locais e sem internet.
- [ ] Favoritar e remover destino; testar filtro de tema e orçamento.
- [ ] Conferir gráficos, filtros, CSV, alteração de despesa prevista para realizada.
