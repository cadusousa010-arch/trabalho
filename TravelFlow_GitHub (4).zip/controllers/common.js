const {prepare}=require('../helpers/forms');
const wrap=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
const plain=x=>x?.get?x.get({plain:true}):x;
const rows=xs=>xs.map(plain);
function flash(req,msg){req.session.flash=msg;}
function form(res,title,action,fs,data={},back='/'){res.render('form',{title,action,fields:prepare(fs,data),back});}
function notFound(){const e=new Error('Registro não encontrado ou sem permissão.');e.status=404;throw e;}
module.exports={wrap,plain,rows,flash,form,notFound};
