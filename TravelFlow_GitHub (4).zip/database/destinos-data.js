const destinos=[
 ['Paris','Paris','Île-de-France','França','internacional',9500,'Torre Eiffel, Louvre e passeios pelo Sena','Uma viagem pela arte, gastronomia e arquitetura.','https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&auto=format&fit=crop'],
 ['Londres','Londres','Inglaterra','Reino Unido','internacional',9800,'Big Ben, museus e Tower Bridge','História, cultura e parques urbanos.','https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800&auto=format&fit=crop'],
 ['Nova York','Nova York','Nova York','Estados Unidos','internacional',10500,'Central Park, Times Square e museus','Explore bairros, parques e grandes atrações.','https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800&auto=format&fit=crop'],
 ['Gramado','Gramado','Rio Grande do Sul','Brasil','nacional',2500,'Lago Negro e Rua Coberta','Passeios pela Serra Gaúcha e gastronomia local.',null],
 ['Rio de Janeiro','Rio de Janeiro','Rio de Janeiro','Brasil','nacional',2200,'Cristo Redentor, Pão de Açúcar e praias','Praias, paisagens e cultura carioca.',null],
 ['Fernando de Noronha','Fernando de Noronha','Pernambuco','Brasil','nacional',6500,'Baía do Sancho e trilhas','Natureza, mar e atividades ao ar livre.',null],
 ['Cancún','Cancún','Quintana Roo','México','internacional',8000,'Praias, cenotes e sítios arqueológicos da região','Sol, mar e passeios culturais.',null],
 ['Dubai','Dubai','Dubai','Emirados Árabes Unidos','internacional',11000,'Burj Khalifa, mercados e passeios no deserto','Arquitetura moderna e experiências culturais.',null],
 ['Orlando','Orlando','Flórida','Estados Unidos','internacional',12000,'Parques temáticos e atrações familiares','Diversão para planejar em família.',null] ,
 ['Porto de Galinhas','Ipojuca','Pernambuco','Brasil','nacional',2800,'Piscinas naturais e praias','Relaxe entre águas claras e piscinas naturais.',null],
 ['Maragogi','Maragogi','Alagoas','Brasil','nacional',3200,'Galés e praias','Paisagens do litoral alagoano.',null],
 ['Salvador','Salvador','Bahia','Brasil','nacional',2600,'Pelourinho e Farol da Barra','Cultura, música e gastronomia baiana.',null],
 ['Florianópolis','Florianópolis','Santa Catarina','Brasil','nacional',2900,'Lagoa da Conceição e praias','Ilha com trilhas, lagoas e praias.',null],
 ['Foz do Iguaçu','Foz do Iguaçu','Paraná','Brasil','nacional',3400,'Cataratas e Parque das Aves','Natureza e grandes paisagens.',null],
 ['Bonito','Bonito','Mato Grosso do Sul','Brasil','nacional',4100,'Rios cristalinos e grutas','Ecoturismo e flutuação em águas transparentes.',null],
 ['Campos do Jordão','Campos do Jordão','São Paulo','Brasil','nacional',1800,'Capivari e parques','Clima de montanha e arquitetura serrana.',null],
 ['Roma','Roma','Lácio','Itália','internacional',9700,'Coliseu e Fórum Romano','História e arte em cada bairro.',null],
 ['Lisboa','Lisboa','Lisboa','Portugal','internacional',7800,'Belém e Alfama','Miradouros, história e gastronomia.',null],
 ['Buenos Aires','Buenos Aires','Buenos Aires','Argentina','internacional',4300,'Recoleta e San Telmo','Tango, cafés e cultura urbana.',null],
 ['Maldivas','Malé','Kaafu','Maldivas','internacional',15000,'Atóis e recifes','Paisagens tropicais e atividades no mar.',null]
];
const extras=[['Romântico','Paris','paris'],['Cultura e história','London','londres'],['Grandes cidades','New York City','nova-york'],['Montanhas','Gramado','gramado'],['Praias','Rio de Janeiro','rio-de-janeiro'],['Natureza','Fernando de Noronha','fernando-de-noronha'],['Praias','Cancún','cancun'],['Grandes cidades','Dubai','dubai'],['Família','Orlando, Florida','orlando'],['Praias','Porto de Galinhas','porto-de-galinhas'],['Praias','Maragogi','maragogi'],['Cultura e história','Salvador, Bahia','salvador'],['Praias','Florianópolis','florianopolis'],['Natureza','Iguazu Falls','foz-do-iguacu'],['Aventura','Bonito, Mato Grosso do Sul','bonito'],['Montanhas','Campos do Jordão','campos-do-jordao'],['Cultura e história','Rome','roma'],['Cultura e história','Lisbon','lisboa'],['Grandes cidades','Buenos Aires','buenos-aires'],['Romântico','Maldives','maldivas']];
module.exports=destinos.map((d,i)=>{const [nome,cidade,estado,pais,categoria,valor_estimado,atracoes,descricao,imagem]=d;const [tema,article,slug]=extras[i];return {nome,cidade,estado,pais,categoria,valor_estimado,atracoes,descricao,imagem,tema,article,slug};});
