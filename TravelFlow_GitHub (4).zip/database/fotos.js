// TravelFlow 2.0: substitua database/fotos.js. Node 20+.
require('dotenv').config();
const fs = require('node:fs/promises');
const path = require('node:path');
const { Destino } = require('../models');
const db = require('../config/database');
const catalog = require('./destinos-data');
const dir = path.join(__dirname, '../public/images/destinos');
const headers = {'User-Agent': 'TravelFlowSchool/2.1 (local educational photo downloader)', 'Accept': '*/*'};
const sleep = ms => new Promise(r => setTimeout(r, ms));
let bloqueado = false;
const names = {'nova-york':'Nova Iorque','orlando':'Orlando','bonito':'Bonito (Mato Grosso do Sul)','foz-do-iguacu':'Cataratas do Iguaçu','porto-de-galinhas':'Porto de Galinhas'};
function imageType(b) {
  if (b.length < 20) return null;
  if (b[0] === 255 && b[1] === 216 && b[2] === 255) return 'jpg';
  if (b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return 'png';
  if (b.toString('ascii',0,4)==='RIFF' && b.toString('ascii',8,12)==='WEBP') return 'webp';
  return null;
}
async function get(url) {
  if (!/^https:\/\/(?:[a-z]+\.wikipedia\.org|commons\.wikimedia\.org|upload\.wikimedia\.org)\//i.test(url)) throw Error('Endereço de imagem não permitido');
  if (bloqueado) throw Error('HTTP 429: aguarde a liberação do serviço antes de tentar novamente.');
  for (let n=0;n<3;n++) {
    try {
      await sleep(3000);
      const r=await fetch(url,{headers,signal:AbortSignal.timeout(22000)});
      if (r.status===429) {
        bloqueado=true;
        throw Error('HTTP 429: limite temporário; Retry-After: '+(r.headers.get('retry-after')||'não informado'));
      }
      if (r.ok) return r;
      if (![429,500,502,503,504].includes(r.status)||n===2) throw Error('HTTP '+r.status);
      const seconds=Number(r.headers.get('retry-after'))||2*(n+1);
      await sleep(Math.min(seconds,15)*1000);
    } catch(e) {
      if(bloqueado || n===2 || /^HTTP (?!429|500|502|503|504)/.test(e.message)) throw e;
      await sleep(1000*(n+1));
    }
  }
}
async function api(host,params) {
  const response=await get('https://'+host+'/w/api.php?'+new URLSearchParams({...params,format:'json',formatversion:'2'}));
  const data=await response.json(); if(data.error) throw Error(data.error.info||data.error.code); return data;
}
const clean = s => String(s||'').replace(/<[^>]*>/g,'').replace(/&amp;/g,'&');
async function existing(slug) {
  for (const ext of ['jpg','jpeg','png','webp']) {
    const file=slug+'.'+ext;
    try {const b=await fs.readFile(path.join(dir,file)); if(imageType(b)) return file;}catch{}
  }
}
async function download(d) {
  const errors=[];
  for (const [lang,title] of [['pt',names[d.slug]||d.nome],['en',d.article]]) {
    try {
      const p=await api(lang+'.wikipedia.org',{action:'query',prop:'pageimages',piprop:'name',pilicense:'free',redirects:'1',titles:title});
      const file=p.query?.pages?.[0]?.pageimage;
      if (!file) throw Error('Sem imagem livre no artigo');
      const c=await api('commons.wikimedia.org',{action:'query',titles:'File:'+file,prop:'imageinfo',iiprop:'url|extmetadata|mime|size',iiurlwidth:'960'});
      const info=c.query?.pages?.[0]?.imageinfo?.[0],m=info?.extmetadata||{};
      const license=clean(m.LicenseShortName?.value);
      if(!info || !/^(CC BY(?:-SA)? [\d.]+(?: [A-Za-z]+)?|CC0(?: 1\.0)?|Public domain)$/i.test(license)) throw Error('Licença não confirmada: '+license);
      if(!/^image\/(jpeg|png|webp)$/.test(info.mime)) throw Error('Formato não suportado: '+info.mime);
      for(const url of [...new Set([info.thumburl,info.size<=10e6?info.url:null].filter(Boolean))]){
        try {
          const r=await get(url);
          if(Number(r.headers.get('content-length'))>12e6) throw Error('Imagem grande demais');
          const bytes=Buffer.from(await r.arrayBuffer()); const ext=imageType(bytes);
          if(!ext||bytes.length>12e6) throw Error('Conteúdo inválido ou maior que 12 MB');
          const local=d.slug+'.'+ext;
          await fs.writeFile(path.join(dir,local),bytes);
          return {local,credit:{destino:d.nome,arquivo:file,autor:clean(m.Artist?.value),licenca:license,urlLicenca:clean(m.LicenseUrl?.value),fonte:info.descriptionurl}};
        }catch(e){errors.push(lang+' download: '+e.message);}
      }
    } catch(e){if(bloqueado) throw e; errors.push(lang+': '+e.message+(e.cause?.code?' ('+e.cause.code+')':''));}
  }
  throw Error(errors.join('; ')||'Nenhum arquivo encontrado');
}
(async()=>{
  let ok=0,fail=0;const missing=[];await fs.mkdir(dir,{recursive:true});
  let credits={};try{credits=JSON.parse(await fs.readFile(path.join(dir,'creditos.json'),'utf8'));}catch{}
  try {
    await db.authenticate();
    for(const d of catalog){
      try {
        const row=await Destino.findOne({where:{nome:d.nome,cidade:d.cidade,pais:d.pais}});
        if(!row) throw Error('Destino ausente; execute npm run seed');
        let local=await existing(d.slug);
        if(!local){if(bloqueado) throw Error('Download adiado pelo limite temporário da Wikimedia');const result=await download(d);local=result.local;credits[d.slug]=result.credit;await fs.writeFile(path.join(dir,'creditos.json'),JSON.stringify(credits,null,2));}
        await row.update({imagem:'/images/destinos/'+local});
        if(d.slug==='rio-de-janeiro' && /\.jpe?g$/i.test(local))await fs.copyFile(path.join(dir,local),path.join(dir,'hero.jpg'));
        ok++;console.log('OK '+d.nome+' -> '+local);
      }catch(e){fail++;missing.push(d.slug);console.warn('FALHA '+d.nome+': '+e.message);}
      await sleep(500);
    }
    console.log(`\nResultado: ${ok} fotos vinculadas; ${fail} pendentes.`);
    if(fail){console.log('Arquivos que faltam: '+missing.join(', '));console.log('Adicione fotos JPG/PNG/WebP com esses nomes em public/images/destinos e execute npm run fotos:locais.');process.exitCode=1;}
    console.log('Confira visualmente as fotos e os créditos.');
  }catch(e){console.error('Falha no banco ou no script:',e.message);process.exitCode=1;}finally{await db.close();}
})();
