USE travelflow;
CREATE TABLE IF NOT EXISTS listas_viagem (
 id INT AUTO_INCREMENT PRIMARY KEY, viagem_id INT NOT NULL, titulo VARCHAR(100) NOT NULL,
 posicao INT NOT NULL, etapa ENUM('aberta','concluida') NOT NULL DEFAULT 'aberta',
 FOREIGN KEY(viagem_id) REFERENCES viagens(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS favoritos (
 usuario_id INT NOT NULL, destino_id INT NOT NULL, PRIMARY KEY(usuario_id,destino_id),
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
 FOREIGN KEY(destino_id) REFERENCES destinos(id) ON DELETE CASCADE
) ENGINE=InnoDB;
-- MariaDB (XAMPP) e MySQL: adicionar colunas somente quando ausentes.
DROP PROCEDURE IF EXISTS tf_upgrade_v2;
DELIMITER $$
CREATE PROCEDURE tf_upgrade_v2()
BEGIN
 IF NOT EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='tarefas' AND COLUMN_NAME='lista_id') THEN
  ALTER TABLE tarefas ADD lista_id INT NULL, ADD posicao INT NOT NULL DEFAULT 0, ADD responsavel_id INT NULL,
  ADD CONSTRAINT tf_tarefa_lista FOREIGN KEY(lista_id) REFERENCES listas_viagem(id) ON DELETE SET NULL,
  ADD CONSTRAINT tf_tarefa_responsavel FOREIGN KEY(responsavel_id) REFERENCES usuarios(id) ON DELETE SET NULL;
 END IF;
 IF NOT EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='destinos' AND COLUMN_NAME='tema') THEN
  ALTER TABLE destinos ADD tema VARCHAR(50) NULL;
 END IF;
 ALTER TABLE despesas MODIFY categoria ENUM('transporte','hospedagem','alimentacao','passeios','compras','outros','seguro') NOT NULL;
END$$
DELIMITER ;
CALL tf_upgrade_v2();
DROP PROCEDURE tf_upgrade_v2;
START TRANSACTION;
CREATE TEMPORARY TABLE tf_antigas (id INT PRIMARY KEY);
INSERT INTO tf_antigas SELECT v.id FROM viagens v WHERE NOT EXISTS(SELECT 1 FROM listas_viagem l WHERE l.viagem_id=v.id);
INSERT INTO listas_viagem(viagem_id,titulo,posicao,etapa)
SELECT id,'A fazer',1,'aberta' FROM tf_antigas;
INSERT INTO listas_viagem(viagem_id,titulo,posicao,etapa) SELECT id,'Fazendo',2,'aberta' FROM tf_antigas;
INSERT INTO listas_viagem(viagem_id,titulo,posicao,etapa) SELECT id,'Concluído',3,'concluida' FROM tf_antigas;
DROP TEMPORARY TABLE tf_antigas;
UPDATE tarefas t SET lista_id=(SELECT l.id FROM listas_viagem l WHERE l.viagem_id=t.viagem_id AND l.etapa=IF(t.concluido,'concluida','aberta') ORDER BY l.posicao,l.id LIMIT 1),posicao=t.id WHERE lista_id IS NULL;
COMMIT;
