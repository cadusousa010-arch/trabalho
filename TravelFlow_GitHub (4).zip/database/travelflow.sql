CREATE DATABASE IF NOT EXISTS travelflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE travelflow;
CREATE TABLE IF NOT EXISTS usuarios (
 id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100) NOT NULL, email VARCHAR(150) NOT NULL UNIQUE,
 senha VARCHAR(255) NOT NULL, tipo ENUM('admin','usuario') NOT NULL DEFAULT 'usuario', ativo BOOLEAN NOT NULL DEFAULT TRUE,
 criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS destinos (
 id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100) NOT NULL, cidade VARCHAR(100) NOT NULL, estado VARCHAR(100) NOT NULL,
 pais VARCHAR(100) NOT NULL, descricao TEXT NOT NULL, imagem VARCHAR(500), categoria ENUM('nacional','internacional') NOT NULL,
 valor_estimado DECIMAL(12,2) NOT NULL DEFAULT 0, atracoes TEXT, ativo BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE(nome,cidade,pais), CHECK(valor_estimado >= 0)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS viagens (
 id INT AUTO_INCREMENT PRIMARY KEY, usuario_id INT NOT NULL, destino_id INT NOT NULL, titulo VARCHAR(150) NOT NULL,
 descricao TEXT, data_ida DATE NOT NULL, data_retorno DATE NOT NULL, quantidade_viajantes INT NOT NULL DEFAULT 1,
 orcamento DECIMAL(12,2) NOT NULL DEFAULT 0, transporte VARCHAR(100), hospedagem VARCHAR(150), observacoes TEXT,
 status ENUM('planejando','em_viagem','concluida') NOT NULL DEFAULT 'planejando', criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE, FOREIGN KEY(destino_id) REFERENCES destinos(id) ON DELETE RESTRICT,
 CHECK(data_retorno >= data_ida), CHECK(quantidade_viajantes > 0), CHECK(orcamento >= 0)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS tarefas (
 id INT AUTO_INCREMENT PRIMARY KEY, viagem_id INT NOT NULL, titulo VARCHAR(150) NOT NULL, descricao TEXT,
 prioridade ENUM('baixa','media','alta') NOT NULL DEFAULT 'media', data_entrega DATE NOT NULL, concluido BOOLEAN NOT NULL DEFAULT FALSE,
 FOREIGN KEY(viagem_id) REFERENCES viagens(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS roteiros (
 id INT AUTO_INCREMENT PRIMARY KEY, viagem_id INT NOT NULL, data DATE NOT NULL, horario TIME NOT NULL, local VARCHAR(150) NOT NULL,
 atividade VARCHAR(150) NOT NULL, valor_estimado DECIMAL(12,2) NOT NULL DEFAULT 0, observacoes TEXT,
 FOREIGN KEY(viagem_id) REFERENCES viagens(id) ON DELETE CASCADE, CHECK(valor_estimado >= 0)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS despesas (
 id INT AUTO_INCREMENT PRIMARY KEY, viagem_id INT NOT NULL, descricao VARCHAR(150) NOT NULL,
 categoria ENUM('transporte','hospedagem','alimentacao','passeios','compras','outros') NOT NULL,
 valor DECIMAL(12,2) NOT NULL, data DATE NOT NULL, tipo ENUM('prevista','realizada') NOT NULL,
 FOREIGN KEY(viagem_id) REFERENCES viagens(id) ON DELETE CASCADE, CHECK(valor >= 0)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS etiquetas (
 id INT AUTO_INCREMENT PRIMARY KEY, viagem_id INT NOT NULL, nome VARCHAR(50) NOT NULL, cor CHAR(7) NOT NULL,
 FOREIGN KEY(viagem_id) REFERENCES viagens(id) ON DELETE CASCADE, UNIQUE(viagem_id,nome)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS tarefa_etiqueta (
 tarefa_id INT NOT NULL, etiqueta_id INT NOT NULL, PRIMARY KEY(tarefa_id,etiqueta_id),
 FOREIGN KEY(tarefa_id) REFERENCES tarefas(id) ON DELETE CASCADE, FOREIGN KEY(etiqueta_id) REFERENCES etiquetas(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS comentarios (
 id INT AUTO_INCREMENT PRIMARY KEY, tarefa_id INT NOT NULL, usuario_id INT NOT NULL, texto TEXT NOT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(tarefa_id) REFERENCES tarefas(id) ON DELETE CASCADE, FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;
USE travelflow;
CREATE TABLE IF NOT EXISTS listas_viagem (
 id INT AUTO_INCREMENT PRIMARY KEY, viagem_id INT NOT NULL, titulo VARCHAR(100) NOT NULL,
 posicao INT NOT NULL, etapa ENUM('aberta','concluida') NOT NULL DEFAULT 'aberta',
 FOREIGN KEY(viagem_id) REFERENCES viagens(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS favoritos (
 usuario_id INT NOT NULL, destino_id INT NOT NULL, PRIMARY KEY(usuario_id,destino_id),
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
 FOREIGN KEY(destino_id) REFERENCES destinos(id) ON DELETE CASCADE
) ENGINE=InnoDB;
-- MariaDB (XAMPP) e MySQL: adicionar colunas somente quando ausentes.
DROP PROCEDURE IF EXISTS tf_upgrade_v2;
DELIMITER $$
CREATE PROCEDURE tf_upgrade_v2()
BEGIN
 IF NOT EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='tarefas' AND COLUMN_NAME='lista_id') THEN
  ALTER TABLE tarefas ADD lista_id INT NULL, ADD posicao INT NOT NULL DEFAULT 0, ADD responsavel_id INT NULL,
  ADD CONSTRAINT tf_tarefa_lista FOREIGN KEY(lista_id) REFERENCES listas_viagem(id) ON DELETE SET NULL,
  ADD CONSTRAINT tf_tarefa_responsavel FOREIGN KEY(responsavel_id) REFERENCES usuarios(id) ON DELETE SET NULL;
 END IF;
 IF NOT EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='destinos' AND COLUMN_NAME='tema') THEN
  ALTER TABLE destinos ADD tema VARCHAR(50) NULL;
 END IF;
 ALTER TABLE despesas MODIFY categoria ENUM('transporte','hospedagem','alimentacao','passeios','compras','outros','seguro') NOT NULL;
END$$
DELIMITER ;
CALL tf_upgrade_v2();
DROP PROCEDURE tf_upgrade_v2;
START TRANSACTION;
CREATE TEMPORARY TABLE tf_antigas (id INT PRIMARY KEY);
INSERT INTO tf_antigas SELECT v.id FROM viagens v WHERE NOT EXISTS(SELECT 1 FROM listas_viagem l WHERE l.viagem_id=v.id);
INSERT INTO listas_viagem(viagem_id,titulo,posicao,etapa)
SELECT id,'A fazer',1,'aberta' FROM tf_antigas;
INSERT INTO listas_viagem(viagem_id,titulo,posicao,etapa) SELECT id,'Fazendo',2,'aberta' FROM tf_antigas;
INSERT INTO listas_viagem(viagem_id,titulo,posicao,etapa) SELECT id,'Concluído',3,'concluida' FROM tf_antigas;
DROP TEMPORARY TABLE tf_antigas;
UPDATE tarefas t SET lista_id=(SELECT l.id FROM listas_viagem l WHERE l.viagem_id=t.viagem_id AND l.etapa=IF(t.concluido,'concluida','aberta') ORDER BY l.posicao,l.id LIMIT 1),posicao=t.id WHERE lista_id IS NULL;
COMMIT;
