const status=[['planejando','Planejando'],['em_viagem','Em viagem'],['concluida','Concluída']];
const categories=[['transporte','Transporte'],['hospedagem','Hospedagem'],['alimentacao','Alimentação'],['passeios','Passeios'],['compras','Compras'],['outros','Outros gastos'],['seguro','Seguro-viagem']];
const f=(name,label,type='text',required=true,max=150)=>({name,label,type,required,max});
const sel=(name,label,options)=>({...f(name,label,'select'),options:options.map(([value,label])=>({value,label}))});
const money=(name,label)=>({...f(name,label,'number'),min:0,max:9999999999.99,step:'0.01'});
const forms={
 destino:[f('nome','Nome', 'text',true,100),f('cidade','Cidade','text',true,100),f('estado','Estado / região','text',true,100),f('pais','País','text',true,100),f('descricao','Descrição','textarea',true,5000),f('imagem','Fotografia (HTTPS ou /images/destinos/arquivo)','imagepath',false,500),f('tema','Tema do destino','text',false,50),sel('categoria','Categoria',[['nacional','Nacional'],['internacional','Internacional']]),money('valor_estimado','Valor estimado (R$)'),f('atracoes','Atrações','textarea',false,5000),sel('ativo','Situação',[['1','Ativo'],['0','Inativo']])],
 viagem:[f('titulo','Título'),sel('destino_id','Destino',[]),f('descricao','Descrição','textarea',false,5000),f('data_ida','Data de ida','date'),f('data_retorno','Data de retorno','date'),{...f('quantidade_viajantes','Viajantes','number'),min:1,max:1000,step:'1'},money('orcamento','Orçamento (R$)'),f('transporte','Transporte','text',false,100),f('hospedagem','Hospedagem','text',false),f('observacoes','Observações','textarea',false,5000),sel('status','Situação',status)],
 tarefa:[f('titulo','Título'),f('descricao','Descrição','textarea',false,5000),sel('prioridade','Prioridade',[['baixa','Baixa'],['media','Média'],['alta','Alta']]),f('data_entrega','Prazo','date')],
 roteiro:[f('data','Data','date'),f('horario','Horário','time'),f('local','Local'),f('atividade','Atividade'),money('valor_estimado','Valor estimado (R$)'),f('observacoes','Observações','textarea',false,5000)],
 despesa:[f('descricao','Descrição'),sel('categoria','Categoria',categories),money('valor','Valor (R$)'),f('data','Data','date'),sel('tipo','Tipo',[['prevista','Prevista'],['realizada','Realizada']])],
 etiqueta:[f('nome','Nome','text',true,50),f('cor','Cor','color')],
 usuario:[f('nome','Nome completo','text',true,100),f('email','E-mail','email',true,150),f('senha','Senha','password',true,72),sel('ativo','Situação',[['1','Ativo'],['0','Inativo']])],
 perfil:[f('nome','Nome completo','text',true,100),f('email','E-mail','email',true,150),f('senha_atual','Senha atual','password',true,72),f('senha','Nova senha (opcional)','password',false,72),f('confirmacao','Confirme a nova senha','password',false,72)],
 cadastro:[f('nome','Nome completo','text',true,100),f('email','E-mail','email',true,150),f('senha','Senha','password',true,72),f('confirmacao','Confirme a senha','password',true,72)],
 login:[f('email','E-mail','email',true,150),f('senha','Senha','password',true,72)]
};
function fields(key,options={}){let a=forms[key].map(x=>({...x}));if(key==='viagem')a.find(x=>x.name==='destino_id').options=options.destinos||[];if(key==='usuario'&&options.edit)a.find(x=>x.name==='senha').required=false;return a;}
function fail(message){const e=new Error(message);e.status=400;throw e;}
function validate(fields,body){const out={};for(const x of fields){let v=body[x.name];if(typeof v!=='string')v='';if(x.type!=='password')v=v.trim();if(!v){if(x.required)fail('Preencha '+x.label+'.');out[x.name]=null;continue;}
 if(x.type==='select'&&!x.options.some(o=>String(o.value)===v))fail('Opção inválida: '+x.label);
 if(x.type==='number'){if(!/^\d+(\.\d{1,2})?$/.test(v)||Number(v)<x.min||Number(v)>x.max||(x.step==='1'&&!Number.isInteger(Number(v))))fail('Valor inválido: '+x.label);}
 else if(x.type!=='select'&&v.length>x.max)fail('Campo muito longo: '+x.label);
 if(x.type==='email'){v=v.toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))fail('E-mail inválido.');}
 if(x.type==='imagepath'&& !/^\/images\/destinos\/[a-zA-Z0-9_.-]+\.(jpg|jpeg|png|webp)$/i.test(v)){try{const u=new URL(v);if(u.protocol!=='https:'||u.username||u.password)throw Error();}catch{fail('Use uma URL HTTPS válida.');}}
 if(x.type==='date'&&(!/^\d{4}-\d{2}-\d{2}$/.test(v)||!Number.isFinite(Date.parse(v))||new Date(v).toISOString().slice(0,10)!==v||v<'1000-01-01'))fail('Data inválida.');
 if(x.type==='time'&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(v))fail('Horário inválido.');
 if(x.type==='color'&&!/^#[0-9a-f]{6}$/i.test(v))fail('Cor inválida.');
 if(x.type==='password'&&Buffer.byteLength(v)>72)fail('Senha muito longa.');
 out[x.name]=v;
 }return out;}
function password(v){if(!v||v.length<8)fail('A senha precisa de pelo menos 8 caracteres.');}
function prepare(fs,data={}){return fs.map(x=>({...x,value:x.type==='password'?'':(x.type==='time'?String(data[x.name]||'').slice(0,5):data[x.name]??''),isSelect:x.type==='select',isTextarea:x.type==='textarea',isNumber:x.type==='number',isPassword:x.type==='password',isImage:x.type==='imagepath',options:x.options?.map(o=>({...o,selected:String(o.value)===String(typeof data[x.name]==='boolean'?Number(data[x.name]):data[x.name])}))}));}
module.exports={fields,validate,prepare,fail,password,status,categories};
