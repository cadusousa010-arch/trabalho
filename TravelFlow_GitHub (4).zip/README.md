# TravelFlow 2.0 — atualização escolar ETEC

Aplicação Node.js + Express + Handlebars + MySQL/MariaDB + Sequelize. Arquitetura MVC, Database First. A versão 2 adiciona listas de tarefas, favoritos, catálogo expandido, design responsivo e relatórios. Não realiza compras ou reservas reais.

## Atualizar a instalação existente (Windows)
1. Pare o servidor no terminal com Ctrl+C. Faça backup da pasta antiga e exporte o banco `travelflow` pelo phpMyAdmin (Exportar, SQL). Guarde o `.env` antigo.
2. Extraia o ZIP em uma pasta própria. Abra no VS Code a pasta que contém `package.json` (neste pacote, os arquivos estão na raiz). Copie o `.env` antigo para essa pasta; se não existir, execute `Copy-Item .env.example .env` e configure os dados de acesso. Não substitua o arquivo de uma instalação existente sem necessidade.
3. No XAMPP, inicie Apache e MySQL. Abra http://localhost/phpmyadmin, selecione o banco `travelflow`, clique Importar e selecione **database/atualizacao_v2.sql**. O script adiciona tabelas e colunas, não apaga os dados. Se houver erro SQL, pare e verifique o erro antes de iniciar o sistema. Requer permissão para ALTER, CREATE TABLE e CREATE PROCEDURE.
4. No terminal da pasta que contém `package.json`, execute um comando por vez:

```powershell
npm install
npm run seed
npm test
npm start
```

5. Abra http://localhost:3000. O seed cria registros de demonstração ausentes e preenche tema de destinos antigos sem alterar senhas ou viagens existentes.

## Fotografias
A geração deste pacote não teve acesso à internet para baixar fotografias. Há ilustrações de indisponibilidade, e as três URLs antigas continuam como alternativas. Para baixar imagens locais com créditos, pare o servidor e execute, com internet:

```powershell
npm run fotos
npm start
```

O script respeita o limite HTTP 429: suspende novas solicitações externas quando o limite é atingido. As fotos locais válidas continuam sendo associadas. Tente novamente após o intervalo indicado pelo servidor ou adicione fotos licenciadas manualmente. O script busca uma imagem livre associada ao artigo de cada destino na Wikipédia e confirma licença no Wikimedia Commons. Salva JPEG, PNG ou WebP local e créditos em `public/images/destinos/creditos.json`, atualiza somente a imagem do destino e tenta copiar a foto do Rio de Janeiro para `hero.jpg`. Nem todos os artigos necessariamente têm uma foto livre adequada: revise visualmente a correspondência e a licença. Se algum falhar, adicione uma foto própria ou licenciada manualmente conforme `public/images/destinos/LEIA-ME.md` e execute `npm run fotos:locais`. Não execute o script de fotos se não quiser substituir as fotos atuais. A galeria com múltiplas imagens não foi implementada.

## Instalação nova
Inicie XAMPP, Apache e MySQL. Importe `database/travelflow.sql` no phpMyAdmin (cria banco e esquema 2.0). Depois, `Copy-Item .env.example .env`, `npm install`, `npm run seed`, `npm test`, `npm start`. Use Node.js 20 ou superior. Ajuste DB_PORT no `.env` se o XAMPP usa 3307. Use SESSION_SECRET longo e aleatório. Não compartilhe `.env`.

## Contas locais de demonstração
- Admin: admin@travelflow.com / Admin@123
- Usuário: usuario@travelflow.com / Usuario@123

Se já alterou a senha, use a senha nova. Não use estas contas em produção.

## Como usar
Usuário: explore destinos, filtre por orçamento/tema, favorite, crie viagem, abra quadro, adicione listas e tarefas, mova cartões pelos botões, conclua/reabra, associe etiquetas e escreva comentários. Cadastre atividades no roteiro e despesas. A lista Concluído e pelo menos uma lista aberta são protegidas contra exclusão. Para excluir lista preenchida, selecione outra lista para transferir cartões. Admin: veja dashboard, usuários, destinos, viagens, tarefas e relatórios CSV; gerenciamento de usuários administrativos é protegido. Perfil exige senha atual para alteração.

## Documentação
`docs/DER.md`, `der.svg`, `DICIONARIO.md`, `REQUISITOS.md`, `ROTAS.md`, `WIREFRAMES.html`, `CONSULTAS.sql`, `APRESENTACAO.md`, `TESTES.md`. A especificação original e a V2 foram mantidas como referência de escopo, não como confirmação de testes.

## Validação e limites
Sintaxe JavaScript verificada e testes unitários sem dependências executados. A instalação npm, renderização completa de Handlebars, migração MySQL, testes de navegador e isolamento de sessões em execução não puderam ser feitos no ambiente de geração. Execute npm test após instalar dependências e siga o checklist local. Não use npm audit fix --force sem revisar mudanças. Sessões e limitação de login são em memória, adequadas à demonstração local, não à publicação na internet. Sem arrastar e soltar, upload de arquivos ou galeria múltipla; os botões de direção e o caminho/URL de fotografia são implementados. As imagens externas dependem de conexão e licença.

## Publicação do código no GitHub

Este ZIP tem `package.json` na raiz e inclui o código MVC, scripts SQL, seed, testes e documentação. Não inclui `.env`, `node_modules`, banco com dados pessoais ou fotografias baixadas no computador de outra pessoa.

Se você já tem fotos locais, copie a pasta `public/images/destinos` (incluindo `creditos.json`) da instalação anterior para esta pasta antes do commit. Depois de importar o SQL e executar o seed em uma instalação nova, use `npm run fotos:locais` para associá-las ao banco. Inclua apenas fotografias autorizadas para redistribuição.

1. Crie um repositório vazio no GitHub, de preferência privado para o trabalho escolar. Não marque a criação automática de README.
2. No VS Code, abra a pasta que contém `package.json`. No terminal PowerShell, confira com `Test-Path .\package.json` (deve retornar `True`).
3. Execute os comandos abaixo, substituindo `SEU_USUARIO` pelo nome de usuário do GitHub e `TravelFlow` pelo nome do repositório, se diferente.

```powershell
git init
git add .
git status --short
git commit -m "Projeto TravelFlow 2.0"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/TravelFlow.git
git push -u origin main
```

Revise a lista de arquivos antes de confirmar o commit. `.env` e `node_modules/` não devem aparecer. Não envie exportações de banco que contenham dados pessoais. O SQL incluído cria a estrutura e o seed cria contas e destinos de teste com senhas armazenadas como hash. As credenciais de demonstração são públicas no código, portanto use apenas em localhost.

O GitHub guarda o código; GitHub Pages não executa Node.js/MySQL. Para demonstrar, execute o projeto localmente conforme as instruções acima.
