# Fotografias de destinos
Adicione fotos reais próprias ou com licença de reutilização e registre autor, fonte e licença em creditos.json. Use nomes abaixo, JPG/PNG/WebP. Execute npm run fotos:locais para associar ao MySQL. Para o banner, adicione hero.jpg.

- paris.jpg — Paris
- londres.jpg — Londres
- nova-york.jpg — Nova York
- gramado.jpg — Gramado
- rio-de-janeiro.jpg — Rio de Janeiro
- fernando-de-noronha.jpg — Fernando de Noronha
- cancun.jpg — Cancún
- dubai.jpg — Dubai
- orlando.jpg — Orlando
- porto-de-galinhas.jpg — Porto de Galinhas
- maragogi.jpg — Maragogi
- salvador.jpg — Salvador
- florianopolis.jpg — Florianópolis
- foz-do-iguacu.jpg — Foz do Iguaçu
- bonito.jpg — Bonito
- campos-do-jordao.jpg — Campos do Jordão
- roma.jpg — Roma
- lisboa.jpg — Lisboa
- buenos-aires.jpg — Buenos Aires
- maldivas.jpg — Maldivas
