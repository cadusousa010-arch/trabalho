const db=require('../config/database');
const {D,str,txt,integer,money,date,created,bool,en,id}=require('./fields');
module.exports=db.define('Usuario',{
  id: id(),
  nome: str(100),
  email: {...str(150),unique:true},
  senha: str(255),
  tipo: en(['admin','usuario'],'usuario'),
  ativo: bool(true),
  criado_em: created()
},{tableName:'usuarios',timestamps:false});
