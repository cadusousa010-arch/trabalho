const db=require('../config/database');
const {D,str,txt,integer,money,date,created,bool,en,id}=require('./fields');
module.exports=db.define('Tarefa',{
  id: id(),
  viagem_id: integer(),
  lista_id:{type:D.INTEGER,allowNull:true},
  responsavel_id:{type:D.INTEGER,allowNull:true},
  posicao:integer(0),
  titulo: str(150),
  descricao: txt(true),
  prioridade: en(['baixa','media','alta'],'media'),
  data_entrega: date(),
  concluido: bool(false)
},{tableName:'tarefas',timestamps:false});
