const db=require('../config/database');
const {D,str,txt,integer,money,date,created,bool,en,id}=require('./fields');
module.exports=db.define('Roteiro',{
  id: id(),
  viagem_id: integer(),
  data: date(),
  horario: {type:D.TIME,allowNull:false},
  local: str(150),
  atividade: str(150),
  valor_estimado: money(),
  observacoes: txt(true)
},{tableName:'roteiros',timestamps:false});
