const db=require('../config/database');
const {D,str,txt,integer,money,date,created,bool,en,id}=require('./fields');
module.exports=db.define('TarefaEtiqueta',{
  tarefa_id: {...integer(),primaryKey:true},
  etiqueta_id: {...integer(),primaryKey:true}
},{tableName:'tarefa_etiqueta',timestamps:false});
