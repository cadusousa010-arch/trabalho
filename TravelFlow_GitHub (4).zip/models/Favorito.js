const db=require('../config/database');const {D}=require('./fields');
module.exports=db.define('Favorito',{usuario_id:{type:D.INTEGER,primaryKey:true},destino_id:{type:D.INTEGER,primaryKey:true}},{tableName:'favoritos',timestamps:false});
