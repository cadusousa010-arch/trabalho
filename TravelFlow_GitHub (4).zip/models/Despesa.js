const db=require('../config/database');
const {D,str,txt,integer,money,date,created,bool,en,id}=require('./fields');
module.exports=db.define('Despesa',{
  id: id(),
  viagem_id: integer(),
  descricao: str(150),
  categoria: en(['transporte','hospedagem','alimentacao','passeios','compras','outros','seguro']),
  valor: money(),
  data: date(),
  tipo: en(['prevista','realizada'])
},{tableName:'despesas',timestamps:false});
