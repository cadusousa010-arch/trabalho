const db=require('../config/database');
const {D,str,txt,integer,money,date,created,bool,en,id}=require('./fields');
module.exports=db.define('Comentario',{
  id: id(),
  tarefa_id: integer(),
  usuario_id: integer(),
  texto: txt(),
  criado_em: created()
},{tableName:'comentarios',timestamps:false});
