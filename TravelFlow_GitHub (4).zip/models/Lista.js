const db=require('../config/database');const {id,integer,str,en}=require('./fields');
module.exports=db.define('Lista',{id:id(),viagem_id:integer(),titulo:str(100),posicao:integer(0),etapa:en(['aberta','concluida'],'aberta')},{tableName:'listas_viagem',timestamps:false});
