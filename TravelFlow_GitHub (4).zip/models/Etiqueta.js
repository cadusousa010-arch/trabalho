const db=require('../config/database');
const {D,str,txt,integer,money,date,created,bool,en,id}=require('./fields');
module.exports=db.define('Etiqueta',{
  id: id(),
  viagem_id: integer(),
  nome: str(50),
  cor: {type:D.CHAR(7),allowNull:false}
},{tableName:'etiquetas',timestamps:false});
