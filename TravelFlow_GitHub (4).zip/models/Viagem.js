const db=require('../config/database');
const {D,str,txt,integer,money,date,created,bool,en,id}=require('./fields');
module.exports=db.define('Viagem',{
  id: id(),
  usuario_id: integer(),
  destino_id: integer(),
  titulo: str(150),
  descricao: txt(true),
  data_ida: date(),
  data_retorno: date(),
  quantidade_viajantes: integer(1),
  orcamento: money(),
  transporte: str(100,true),
  hospedagem: str(150,true),
  observacoes: txt(true),
  status: en(['planejando','em_viagem','concluida'],'planejando'),
  criado_em: created()
},{tableName:'viagens',timestamps:false});
