const db=require('../config/database');
const {D,str,txt,integer,money,date,created,bool,en,id}=require('./fields');
module.exports=db.define('Destino',{
  id: id(),
  nome: str(100),
  cidade: str(100),
  estado: str(100),
  pais: str(100),
  descricao: txt(),
  imagem: str(500,true),
  tema:str(50,true),
  categoria: en(['nacional','internacional']),
  valor_estimado: money(),
  atracoes: txt(true),
  ativo: bool(true)
},{tableName:'destinos',timestamps:false});
