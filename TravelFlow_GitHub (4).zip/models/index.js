const Usuario=require('./Usuario');
const Destino=require('./Destino');
const Viagem=require('./Viagem');
const Tarefa=require('./Tarefa');
const Roteiro=require('./Roteiro');
const Despesa=require('./Despesa');
const Etiqueta=require('./Etiqueta');
const TarefaEtiqueta=require('./TarefaEtiqueta');
const Comentario=require('./Comentario');
// As tabelas já existem no MySQL; não usamos sync para criá-las.
Usuario.hasMany(Viagem,{foreignKey:'usuario_id'}); Viagem.belongsTo(Usuario,{foreignKey:'usuario_id'});
Destino.hasMany(Viagem,{foreignKey:'destino_id'}); Viagem.belongsTo(Destino,{foreignKey:'destino_id'});
for(const Model of [Tarefa,Roteiro,Despesa,Etiqueta]){
 Viagem.hasMany(Model,{as:Model.name+'s',foreignKey:'viagem_id'}); Model.belongsTo(Viagem,{foreignKey:'viagem_id'});
}
Tarefa.belongsToMany(Etiqueta,{as:'Etiquetas',through:TarefaEtiqueta,foreignKey:'tarefa_id',otherKey:'etiqueta_id'});
Etiqueta.belongsToMany(Tarefa,{through:TarefaEtiqueta,foreignKey:'etiqueta_id',otherKey:'tarefa_id'});
Tarefa.hasMany(Comentario,{foreignKey:'tarefa_id'}); Comentario.belongsTo(Tarefa,{foreignKey:'tarefa_id'});
Usuario.hasMany(Comentario,{foreignKey:'usuario_id'}); Comentario.belongsTo(Usuario,{foreignKey:'usuario_id'});
const Lista=require('./Lista'),Favorito=require('./Favorito');
Viagem.hasMany(Lista,{foreignKey:'viagem_id'});Lista.belongsTo(Viagem,{foreignKey:'viagem_id'});
Lista.hasMany(Tarefa,{foreignKey:'lista_id'});Tarefa.belongsTo(Lista,{foreignKey:'lista_id'});
Tarefa.belongsTo(Usuario,{as:'Responsavel',foreignKey:'responsavel_id'});
Usuario.belongsToMany(Destino,{as:'Favoritos',through:Favorito,foreignKey:'usuario_id',otherKey:'destino_id'});
module.exports={Lista,Favorito,Usuario,Destino,Viagem,Tarefa,Roteiro,Despesa,Etiqueta,TarefaEtiqueta,Comentario};
